# Deployment Guide

This guide covers deploying the Digital Products Marketplace platform to production environments.

## Environment Variables

### Required Environment Variables

```bash
# Database
DATABASE_URL=postgresql://username:password@host:port/database

# NextAuth.js
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=your-secure-secret-key-here

# CORS Configuration
ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com

# Server Configuration
PORT=3000
NODE_ENV=production
```

### Database Setup

The application supports multiple database options:

1. **PostgreSQL (Recommended for production)**
   ```bash
   DATABASE_URL=postgresql://username:password@host:port/database
   ```

2. **MySQL**
   ```bash
   DATABASE_URL=mysql://username:password@host:port/database
   ```

## Deployment Platforms

### AWS ECS/EC2 with Application Load Balancer

1. **Build the application:**
   ```bash
   npm run build
   ```

2. **Dockerfile (if using containers):**
   ```dockerfile
   FROM node:18-alpine
   
   WORKDIR /app
   
   COPY package*.json ./
   RUN npm ci --only=production
   
   COPY . .
   RUN npm run build
   
   EXPOSE 3000
   
   CMD ["npm", "start"]
   ```

3. **Health Check Configuration:**
   - Health check endpoint: `/api/health`
   - Expected response: `{"status": "healthy"}`
   - Grace period: 30 seconds
   - Interval: 10 seconds
   - Timeout: 5 seconds
   - Healthy threshold: 2
   - Unhealthy threshold: 3

### Vercel Deployment

1. **Install Vercel CLI:**
   ```bash
   npm i -g vercel
   ```

2. **Configure vercel.json:**
   ```json
   {
     "buildCommand": "npm run build",
     "outputDirectory": ".next",
     "installCommand": "npm ci",
     "functions": {
       "src/app/api/**/*.ts": {
         "maxDuration": 30
       }
     }
   }
   ```

3. **Deploy:**
   ```bash
   vercel --prod
   ```

### Docker Deployment

1. **Build image:**
   ```bash
   docker build -t digital-marketplace .
   ```

2. **Run container:**
   ```bash
   docker run -p 3000:3000 \
     -e DATABASE_URL=your-database-url \
     -e NEXTAUTH_URL=https://yourdomain.com \
     -e NEXTAUTH_SECRET=your-secret \
     digital-marketplace
   ```

## Troubleshooting

### 502 Bad Gateway Issues

If you're experiencing 502 Bad Gateway errors with ALB:

1. **Check server binding:**
   - Ensure the server binds to `0.0.0.0` in production
   - Verify the PORT environment variable is set correctly

2. **Health check failures:**
   - Test the health endpoint: `curl https://yourdomain.com/api/health`
   - Check database connectivity
   - Review application logs

3. **Database connection issues:**
   - Verify DATABASE_URL is correct
   - Check database server accessibility
   - Ensure database schema is up to date

### Common Issues

1. **NextAuth configuration:**
   - Ensure NEXTAUTH_URL matches your domain
   - Generate a secure NEXTAUTH_SECRET
   - Configure proper callback URLs

2. **CORS issues:**
   - Set ALLOWED_ORIGINS environment variable
   - Check Next.js configuration for CORS headers

3. **Database schema:**
   - Run database migrations: `npx prisma migrate deploy`
   - Seed data if needed: `POST /api/seed`

## Performance Optimization

1. **Enable caching:**
   - Configure CDN for static assets
   - Enable database query caching
   - Use Redis for session storage

2. **Database optimization:**
   - Add proper indexes
   - Optimize queries
   - Use connection pooling

3. **Server optimization:**
   - Enable gzip compression
   - Configure proper caching headers
   - Use load balancing for high traffic

## Security Considerations

1. **Environment variables:**
   - Never commit secrets to version control
   - Use secure secret management
   - Rotate secrets regularly

2. **Database security:**
   - Use SSL connections
   - Implement proper access controls
   - Regular security updates

3. **Application security:**
   - Enable HTTPS
   - Implement rate limiting
   - Use security headers
   - Regular dependency updates

## Monitoring

1. **Health monitoring:**
   - Monitor `/api/health` endpoint
   - Set up alerts for downtime
   - Track response times

2. **Error tracking:**
   - Implement error logging
   - Set up alerting for critical errors
   - Monitor database performance

3. **Analytics:**
   - Track user metrics
   - Monitor conversion rates
   - Analyze performance bottlenecks