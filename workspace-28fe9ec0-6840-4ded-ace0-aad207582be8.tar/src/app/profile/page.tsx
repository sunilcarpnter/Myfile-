"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  User, 
  Package, 
  Download, 
  Calendar, 
  CreditCard,
  Mail,
  Edit,
  Save,
  X,
  Eye,
  FileText
} from "lucide-react"
import { toast } from "sonner"

interface Order {
  id: string
  totalAmount: number
  status: string
  paymentMethod: string
  createdAt: string
  items: {
    id: string
    quantity: number
    price: number
    downloadUrl: string
    expiresAt: string
    product: {
      id: string
      title: string
      category: string
      screenshots: string
    }
  }[]
}

export default function ProfilePage() {
  const { data: session, update } = useSession()
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isEditingProfile, setIsEditingProfile] = useState(false)
  const [profileData, setProfileData] = useState({
    name: "",
    email: ""
  })

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin?callbackUrl=/profile")
      return
    }
    fetchOrders()
    setProfileData({
      name: session.user?.name || "",
      email: session.user?.email || ""
    })
  }, [session])

  const fetchOrders = async () => {
    try {
      const response = await fetch("/api/orders/list")
      if (response.ok) {
        const data = await response.json()
        setOrders(data)
      }
    } catch (error) {
      console.error("Failed to fetch orders:", error)
      toast.error("Failed to load orders")
    } finally {
      setIsLoading(false)
    }
  }

  const updateProfile = async () => {
    try {
      const response = await fetch("/api/user/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profileData)
      })

      if (response.ok) {
        await update({ name: profileData.name })
        setIsEditingProfile(false)
        toast.success("Profile updated successfully!")
      } else {
        toast.error("Failed to update profile")
      }
    } catch (error) {
      console.error("Failed to update profile:", error)
      toast.error("Failed to update profile")
    }
  }

  const downloadProduct = async (downloadUrl: string, productId: string) => {
    try {
      const response = await fetch(`/api/orders/download/${downloadUrl}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `product-${productId}.zip`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        toast.error("Download link expired or invalid")
      }
    } catch (error) {
      console.error("Failed to download product:", error)
      toast.error("Failed to download product")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "COMPLETED":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "PENDING":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "PROCESSING":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "CANCELLED":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold text-xl">DigitalMarket</span>
            </Link>
            <h1 className="text-xl font-semibold">My Profile</h1>
          </div>
          <Link href="/cart" className="relative">
            <Button variant="ghost" size="icon">
              <Package className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      <div className="container px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="profile" className="space-y-8">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile" className="gap-2">
                <User className="h-4 w-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="orders" className="gap-2">
                <Package className="h-4 w-4" />
                Orders
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Profile Information
                    </CardTitle>
                    {!isEditingProfile ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsEditingProfile(true)}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    ) : (
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setIsEditingProfile(false)
                            setProfileData({
                              name: session?.user?.name || "",
                              email: session?.user?.email || ""
                            })
                          }}
                        >
                          <X className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          onClick={updateProfile}
                        >
                          <Save className="h-4 w-4 mr-2" />
                          Save
                        </Button>
                      </div>
                    )}
                  </div>
                  <CardDescription>
                    Manage your account information and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      {isEditingProfile ? (
                        <Input
                          id="name"
                          value={profileData.name}
                          onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                        />
                      ) : (
                        <div className="flex items-center gap-2 p-2 border rounded-md">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{profileData.name || "Not set"}</span>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      {isEditingProfile ? (
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                        />
                      ) : (
                        <div className="flex items-center gap-2 p-2 border rounded-md">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span>{profileData.email}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Package className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="text-2xl font-bold">{orders.length}</p>
                        <p className="text-sm text-muted-foreground">Total Orders</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <CreditCard className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="text-2xl font-bold">
                          ${orders.reduce((sum, order) => sum + order.totalAmount, 0).toFixed(2)}
                        </p>
                        <p className="text-sm text-muted-foreground">Total Spent</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Calendar className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="text-2xl font-bold">
                          {session?.user?.name ? "Member" : "Guest"}
                        </p>
                        <p className="text-sm text-muted-foreground">Account Type</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Order History
                  </CardTitle>
                  <CardDescription>
                    View your past orders and download purchased products
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {orders.length === 0 ? (
                    <div className="text-center py-12">
                      <Package className="h-24 w-24 text-muted-foreground mx-auto mb-6" />
                      <h3 className="text-xl font-semibold mb-2">No orders yet</h3>
                      <p className="text-muted-foreground mb-6">
                        You haven't placed any orders yet. Start shopping to see your order history here.
                      </p>
                      <Button asChild>
                        <Link href="/products">Start Shopping</Link>
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <Card key={order.id} className="border-l-4 border-l-primary">
                          <CardContent className="p-6">
                            <div className="flex items-start justify-between mb-4">
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <h3 className="font-semibold">Order #{order.id.slice(0, 8)}</h3>
                                  <Badge className={getStatusColor(order.status)}>
                                    {order.status}
                                  </Badge>
                                </div>
                                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                  <div className="flex items-center gap-1">
                                    <Calendar className="h-4 w-4" />
                                    {new Date(order.createdAt).toLocaleDateString()}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <CreditCard className="h-4 w-4" />
                                    {order.paymentMethod}
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-lg font-semibold">${order.totalAmount.toFixed(2)}</p>
                                <Button variant="outline" size="sm" asChild>
                                  <Link href={`/orders/${order.id}`}>
                                    <Eye className="h-4 w-4 mr-2" />
                                    View Details
                                  </Link>
                                </Button>
                              </div>
                            </div>

                            <Separator className="my-4" />

                            <div className="space-y-3">
                              <h4 className="font-medium">Order Items:</h4>
                              {order.items.map((item) => {
                                const screenshots = JSON.parse(item.product.screenshots || "[]")
                                
                                return (
                                  <div key={item.id} className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
                                    <div className="w-12 h-12 bg-muted rounded overflow-hidden flex-shrink-0">
                                      <img
                                        src={screenshots[0] || "/placeholder-product.jpg"}
                                        alt={item.product.title}
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                    <div className="flex-1">
                                      <p className="font-medium">{item.product.title}</p>
                                      <p className="text-sm text-muted-foreground">
                                        {item.quantity} × ${item.price}
                                      </p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      {order.status === "COMPLETED" && (
                                        <Button
                                          size="sm"
                                          onClick={() => downloadProduct(item.downloadUrl, item.product.id)}
                                        >
                                          <Download className="h-4 w-4 mr-2" />
                                          Download
                                        </Button>
                                      )}
                                      <span className="font-semibold">
                                        ${(item.price * item.quantity).toFixed(2)}
                                      </span>
                                    </div>
                                  </div>
                                )
                              })}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}