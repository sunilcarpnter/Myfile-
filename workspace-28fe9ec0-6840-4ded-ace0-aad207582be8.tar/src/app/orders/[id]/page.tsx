"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { 
  CheckCircle, 
  Download, 
  ArrowLeft, 
  Package,
  Calendar,
  CreditCard,
  FileText
} from "lucide-react"

interface OrderItem {
  id: string
  quantity: number
  price: number
  downloadUrl: string
  expiresAt: string
  product: {
    id: string
    title: string
    category: string
    screenshots: string
  }
}

interface Order {
  id: string
  totalAmount: number
  status: string
  paymentMethod: string
  paymentId: string
  currency: string
  taxAmount: number
  discountAmount: number
  couponCode?: string
  createdAt: string
  items: OrderItem[]
}

export default function OrderConfirmationPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const params = useParams()
  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin")
      return
    }
    if (params.id) {
      fetchOrder(params.id as string)
    }
  }, [session, params.id])

  const fetchOrder = async (orderId: string) => {
    try {
      const response = await fetch(`/api/orders/${orderId}`)
      if (response.ok) {
        const data = await response.json()
        setOrder(data)
      } else {
        router.push("/orders")
      }
    } catch (error) {
      console.error("Failed to fetch order:", error)
      router.push("/orders")
    } finally {
      setIsLoading(false)
    }
  }

  const downloadProduct = async (downloadUrl: string, productId: string) => {
    try {
      const response = await fetch(`/api/orders/download/${downloadUrl}`)
      if (response.ok) {
        // Create a download link
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `product-${productId}.zip`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        alert("Download link expired or invalid")
      }
    } catch (error) {
      console.error("Failed to download product:", error)
      alert("Failed to download product")
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Order not found</h1>
          <Button asChild>
            <Link href="/orders">View Orders</Link>
          </Button>
        </div>
      </div>
    )
  }

  const isDownloadAvailable = order.status === "COMPLETED"

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/orders">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <h1 className="text-xl font-semibold">Order Confirmation</h1>
          </div>
        </div>
      </header>

      <div className="container px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Success Message */}
          <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <CheckCircle className="h-12 w-12 text-green-600" />
                <div>
                  <h2 className="text-2xl font-bold text-green-800 dark:text-green-200">
                    Order Placed Successfully!
                  </h2>
                  <p className="text-green-600 dark:text-green-300">
                    Thank you for your purchase. Your order has been received and is being processed.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Order Details */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Order Items */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Order Items
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {order.items.map((item) => {
                    const screenshots = JSON.parse(item.product.screenshots || "[]")
                    
                    return (
                      <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                        <div className="w-16 h-16 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={screenshots[0] || "/placeholder-product.jpg"}
                            alt={item.product.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold">{item.product.title}</h3>
                          <Badge variant="secondary" className="mt-1">
                            {item.product.category}
                          </Badge>
                          <p className="text-sm text-muted-foreground mt-2">
                            Quantity: {item.quantity} × ${item.price}
                          </p>
                          {isDownloadAvailable && (
                            <div className="mt-3 flex items-center gap-2">
                              <Button
                                size="sm"
                                onClick={() => downloadProduct(item.downloadUrl, item.product.id)}
                                className="gap-2"
                              >
                                <Download className="h-4 w-4" />
                                Download
                              </Button>
                              <span className="text-xs text-muted-foreground">
                                Expires: {new Date(item.expiresAt).toLocaleDateString()}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">
                            ${(item.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    )
                  })}
                </CardContent>
              </Card>

              {/* Download Instructions */}
              {isDownloadAvailable && (
                <Card>
                  <CardHeader>
                    <CardTitle>Download Instructions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center flex-shrink-0">
                        1
                      </div>
                      <p className="text-sm">
                        Click the "Download" button next to each product to download your files.
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center flex-shrink-0">
                        2
                      </div>
                      <p className="text-sm">
                        Download links are valid for 30 days from the purchase date.
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center flex-shrink-0">
                        3
                      </div>
                      <p className="text-sm">
                        You can always access your downloads from your order history.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Order ID:</span>
                      <span className="font-mono">{order.id}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Date:</span>
                      <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Payment Method:</span>
                      <span>{order.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Transaction ID:</span>
                      <span className="font-mono text-xs">{order.paymentId}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>${(order.totalAmount - order.taxAmount + order.discountAmount).toFixed(2)}</span>
                    </div>
                    {order.discountAmount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Discount</span>
                        <span>-${order.discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Tax</span>
                      <span>${order.taxAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Total</span>
                      <span>${order.totalAmount.toFixed(2)}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex items-center gap-2">
                    <Badge variant={order.status === "COMPLETED" ? "default" : "secondary"}>
                      {order.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="space-y-3">
                <Button variant="outline" className="w-full gap-2" asChild>
                  <Link href="/orders">
                    <FileText className="h-4 w-4" />
                    View All Orders
                  </Link>
                </Button>
                <Button className="w-full gap-2" asChild>
                  <Link href="/products">
                    <Package className="h-4 w-4" />
                    Continue Shopping
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}