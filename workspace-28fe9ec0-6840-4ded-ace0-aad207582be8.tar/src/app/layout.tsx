import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionProviderWrapper } from "@/components/providers/session-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Digital Marketplace - Premium Digital Products",
  description: "Discover and download premium digital products. From templates to tools, find everything you need for your next project.",
  keywords: ["digital marketplace", "digital products", "templates", "tools", "downloads"],
  authors: [{ name: "Digital Marketplace Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Digital Marketplace",
    description: "Discover and download premium digital products",
    url: "https://digital-marketplace.com",
    siteName: "Digital Marketplace",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Digital Marketplace",
    description: "Discover and download premium digital products",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <SessionProviderWrapper>
          {children}
          <Toaster />
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
