import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { z } from "zod"

const applyCouponSchema = z.object({
  code: z.string().min(1)
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { code } = applyCouponSchema.parse(body)

    // Find the coupon
    const coupon = await db.coupon.findUnique({
      where: { code: code.toUpperCase() }
    })

    if (!coupon) {
      return NextResponse.json(
        { error: "Invalid coupon code" },
        { status: 404 }
      )
    }

    // Check if coupon is active
    if (!coupon.isActive) {
      return NextResponse.json(
        { error: "Coupon is no longer active" },
        { status: 400 }
      )
    }

    // Check if coupon has expired
    if (coupon.expiresAt && new Date() > coupon.expiresAt) {
      return NextResponse.json(
        { error: "Coupon has expired" },
        { status: 400 }
      )
    }

    // Check usage limit
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
      return NextResponse.json(
        { error: "Coupon usage limit reached" },
        { status: 400 }
      )
    }

    // Get user's cart to calculate discount
    const cartItems = await db.cartItem.findMany({
      where: {
        userId: session.user.id
      },
      include: {
        product: {
          select: {
            id: true,
            price: true,
            status: true
          }
        }
      }
    })

    const activeCartItems = cartItems.filter(item => item.product.status === "ACTIVE")
    
    if (activeCartItems.length === 0) {
      return NextResponse.json(
        { error: "Your cart is empty" },
        { status: 400 }
      )
    }

    const subtotal = activeCartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0)

    // Check minimum order amount
    if (coupon.minAmount && subtotal < coupon.minAmount) {
      return NextResponse.json(
        { error: `Minimum order amount of $${coupon.minAmount} required` },
        { status: 400 }
      )
    }

    // Calculate discount
    let discountAmount = 0
    if (coupon.type === "FLAT") {
      discountAmount = Math.min(coupon.value, subtotal)
    } else if (coupon.type === "PERCENTAGE") {
      discountAmount = subtotal * (coupon.value / 100)
    }

    return NextResponse.json({
      code: coupon.code,
      type: coupon.type,
      value: coupon.value,
      discountAmount
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    console.error("Failed to apply coupon:", error)
    return NextResponse.json(
      { error: "Failed to apply coupon" },
      { status: 500 }
    )
  }
}