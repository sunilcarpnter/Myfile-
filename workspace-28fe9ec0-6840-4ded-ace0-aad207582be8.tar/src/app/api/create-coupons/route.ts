import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function POST() {
  try {
    // Create sample coupons
    const coupons = [
      {
        code: "WELCOME10",
        type: "PERCENTAGE",
        value: 10,
        minAmount: 50,
        maxUses: 100,
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days
        isActive: true,
        productIds: null
      },
      {
        code: "SAVE20",
        type: "FLAT",
        value: 20,
        minAmount: 100,
        maxUses: 50,
        expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days
        isActive: true,
        productIds: null
      },
      {
        code: "FIRST5",
        type: "FLAT",
        value: 5,
        minAmount: 25,
        maxUses: 200,
        expiresAt: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000), // 120 days
        isActive: true,
        productIds: null
      }
    ]

    for (const coupon of coupons) {
      await db.coupon.upsert({
        where: { code: coupon.code },
        update: coupon,
        create: coupon
      })
    }

    return NextResponse.json({ message: "Sample coupons created successfully" })
  } catch (error) {
    console.error("Failed to create coupons:", error)
    return NextResponse.json(
      { error: "Failed to create coupons" },
      { status: 500 }
    )
  }
}