import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { z } from "zod"

const createOrderSchema = z.object({
  items: z.array(z.object({
    productId: z.string(),
    quantity: z.number().min(1),
    price: z.number().min(0)
  })),
  totalAmount: z.number().min(0),
  paymentMethod: z.string(),
  couponCode: z.string().optional(),
  customerInfo: z.object({
    email: z.string().email(),
    fullName: z.string().min(1)
  })
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { items, totalAmount, paymentMethod, couponCode, customerInfo } = createOrderSchema.parse(body)

    // Start a transaction
    const result = await db.$transaction(async (tx) => {
      // Create the order
      const order = await tx.order.create({
        data: {
          userId: session.user.id,
          totalAmount,
          status: "PENDING",
          paymentMethod,
          paymentId: `PAY_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          currency: "USD",
          taxAmount: totalAmount * 0.08,
          discountAmount: 0,
          couponCode
        }
      })

      // Create order items
      for (const item of items) {
        await tx.orderItem.create({
          data: {
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            downloadUrl: `DOWNLOAD_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
          }
        })
      }

      // Clear the cart
      await tx.cartItem.deleteMany({
        where: {
          userId: session.user.id
        }
      })

      // Update coupon usage if applicable
      if (couponCode) {
        await tx.coupon.update({
          where: { code: couponCode },
          data: {
            usedCount: {
              increment: 1
            }
          }
        })
      }

      return order
    })

    return NextResponse.json({ 
      message: "Order created successfully",
      orderId: result.id 
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    console.error("Failed to create order:", error)
    return NextResponse.json(
      { error: "Failed to create order" },
      { status: 500 }
    )
  }
}