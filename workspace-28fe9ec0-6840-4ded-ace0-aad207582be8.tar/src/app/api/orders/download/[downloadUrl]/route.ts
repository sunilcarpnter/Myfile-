import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(
  request: NextRequest,
  { params }: { params: { downloadUrl: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    // Find the order item with this download URL
    const orderItem = await db.orderItem.findFirst({
      where: {
        downloadUrl: params.downloadUrl
      },
      include: {
        order: {
          select: {
            userId: true,
            status: true
          }
        },
        product: {
          select: {
            title: true,
            fileUrl: true,
            fileName: true
          }
        }
      }
    })

    if (!orderItem) {
      return NextResponse.json(
        { error: "Download link not found" },
        { status: 404 }
      )
    }

    // Verify the order belongs to the user and is completed
    if (orderItem.order.userId !== session.user.id || orderItem.order.status !== "COMPLETED") {
      return NextResponse.json(
        { error: "Unauthorized download" },
        { status: 403 }
      )
    }

    // Check if download link has expired
    if (orderItem.expiresAt && new Date() > orderItem.expiresAt) {
      return NextResponse.json(
        { error: "Download link expired" },
        { status: 410 }
      )
    }

    // For demo purposes, return a simple file
    // In a real application, you would serve the actual file
    const fileContent = `Thank you for purchasing ${orderItem.product.title}!\n\nThis is a demo download file.\nIn a real application, this would be the actual digital product.`
    
    return new NextResponse(fileContent, {
      headers: {
        'Content-Type': 'text/plain',
        'Content-Disposition': `attachment; filename="${orderItem.product.fileName || 'product.txt'}"`
      }
    })
  } catch (error) {
    console.error("Failed to process download:", error)
    return NextResponse.json(
      { error: "Failed to process download" },
      { status: 500 }
    )
  }
}