import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"
import { z } from "zod"

const updateCartSchema = z.object({
  itemId: z.string(),
  quantity: z.number().min(1)
})

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { itemId, quantity } = updateCartSchema.parse(body)

    // Verify the cart item belongs to the user
    const cartItem = await db.cartItem.findFirst({
      where: {
        id: itemId,
        userId: session.user.id
      }
    })

    if (!cartItem) {
      return NextResponse.json(
        { error: "Cart item not found" },
        { status: 404 }
      )
    }

    // Update the quantity
    const updatedItem = await db.cartItem.update({
      where: { id: itemId },
      data: { quantity }
    })

    return NextResponse.json(updatedItem)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    console.error("Failed to update cart item:", error)
    return NextResponse.json(
      { error: "Failed to update cart item" },
      { status: 500 }
    )
  }
}