import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const cartItems = await db.cartItem.findMany({
      where: {
        userId: session.user.id
      },
      include: {
        product: {
          select: {
            id: true,
            title: true,
            price: true,
            screenshots: true,
            category: true,
            status: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    })

    // Filter out inactive products
    const activeCartItems = cartItems.filter(item => item.product.status === "ACTIVE")

    return NextResponse.json(activeCartItems)
  } catch (error) {
    console.error("Failed to fetch cart items:", error)
    return NextResponse.json(
      { error: "Failed to fetch cart items" },
      { status: 500 }
    )
  }
}