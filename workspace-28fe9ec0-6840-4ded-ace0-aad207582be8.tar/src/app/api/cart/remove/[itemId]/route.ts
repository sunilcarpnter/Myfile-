import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function DELETE(
  request: NextRequest,
  { params }: { params: { itemId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    // Verify the cart item belongs to the user
    const cartItem = await db.cartItem.findFirst({
      where: {
        id: params.itemId,
        userId: session.user.id
      }
    })

    if (!cartItem) {
      return NextResponse.json(
        { error: "Cart item not found" },
        { status: 404 }
      )
    }

    // Delete the cart item
    await db.cartItem.delete({
      where: { id: params.itemId }
    })

    return NextResponse.json({ message: "Item removed from cart" })
  } catch (error) {
    console.error("Failed to remove cart item:", error)
    return NextResponse.json(
      { error: "Failed to remove cart item" },
      { status: 500 }
    )
  }
}