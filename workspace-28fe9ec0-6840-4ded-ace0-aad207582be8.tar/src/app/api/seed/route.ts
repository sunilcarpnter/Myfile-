import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function POST() {
  try {
    // Create sample products
    const products = [
      {
        title: "Premium Website Template",
        description: "A modern, responsive website template built with Next.js and Tailwind CSS. Perfect for businesses and portfolios.",
        price: 49.99,
        category: "Templates",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["nextjs", "tailwind", "responsive", "business"])
      },
      {
        title: "Mobile App UI Kit",
        description: "Complete UI kit for mobile applications with 50+ screens, icons, and components. Compatible with React Native.",
        price: 89.99,
        category: "UI Kits",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["mobile", "ui", "react-native", "design"])
      },
      {
        title: "E-commerce Platform",
        description: "Full-featured e-commerce platform with payment integration, inventory management, and analytics dashboard.",
        price: 199.99,
        category: "Scripts",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["ecommerce", "payment", "dashboard", "inventory"])
      },
      {
        title: "Dashboard Template",
        description: "Professional admin dashboard template with charts, tables, and analytics components. Built with React and D3.js.",
        price: 69.99,
        category: "Templates",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["dashboard", "admin", "charts", "analytics"])
      },
      {
        title: "Social Media Icons Pack",
        description: "Collection of 500+ social media icons in various formats and styles. Perfect for web and mobile projects.",
        price: 19.99,
        category: "Graphics",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["icons", "social", "graphics", "vector"])
      },
      {
        title: "React Component Library",
        description: "Comprehensive React component library with 100+ reusable components, TypeScript support, and documentation.",
        price: 129.99,
        category: "Libraries",
        status: "ACTIVE",
        screenshots: JSON.stringify([
          "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=800&h=600&fit=crop"
        ]),
        tags: JSON.stringify(["react", "components", "typescript", "library"])
      }
    ]

    for (const product of products) {
      await db.product.create({
        data: product
      })
    }

    return NextResponse.json({ message: "Database seeded successfully" })
  } catch (error) {
    console.error("Seeding error:", error)
    return NextResponse.json(
      { error: "Failed to seed database" },
      { status: 500 }
    )
  }
}